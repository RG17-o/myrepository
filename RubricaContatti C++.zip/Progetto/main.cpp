#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <algorithm>

using namespace std;

// Classe Interaction
class Interaction {
private:
    string type;
    string details;

public:
    Interaction(const string& reftype, const string& refdetails)
        : type(reftype), details(refdetails) {}

    string getType() const {
        return type;
    }

    string getDetails() const {
        return details;
    }

    void setDetails(const string& refdetails) {
        this->details = refdetails;
    }
};

// Classe Customer
class Customer {
private:
    int id;
    string firstName;
    string lastName;
    string email;
    vector<Interaction> interactions;

public:
    Customer(int id, const string& firstName, const string& lastName, const string& email)
        : id(id), firstName(firstName), lastName(lastName), email(email) {}

    int getId() const {
        return id;
    }

    string getFirstName() const {
        return firstName;
    }

    string getLastName() const {
        return lastName;
    }

    string getEmail() const {
        return email;
    }

    void setFirstName(const string& firstName) {
        this->firstName = firstName;
    }

    void setLastName(const string& lastName) {
        this->lastName = lastName;
    }

    void setEmail(const string& email) {
        this->email = email;
    }

    void addInteraction(const Interaction& interaction) {
        interactions.push_back(interaction);
    }

    vector<Interaction> getInteractions() const {
        return interactions;
    }
};

// Classe CRMSystem
class CRMSystem {
private:
    vector<Customer> customers;
    int nextCustomerId;

public:
    CRMSystem() : nextCustomerId(1) {}

    // Aggiunge un nuovo cliente al sistema
    void addCustomer(const string& firstName, const string& lastName, const string& email) {
        customers.emplace_back(nextCustomerId++, firstName, lastName, email);
    }

    // Restituisce tutti i clienti
    vector<Customer> getCustomers() const {
        return customers;
    }

    // Trova un cliente per ID
    Customer* findCustomerById(int id) {
        for (auto& customer : customers) {
            if (customer.getId() == id) {
                return &customer;
            }
        }
        return nullptr;
    }

    // Rimuove un cliente per ID
    void removeCustomerById(int id) {
        customers.erase(
            remove_if(customers.begin(), customers.end(), [id](const Customer& customer) {
                return customer.getId() == id;
            }),
            customers.end()
        );
    }

    // Salva i dati dei clienti su un file
    void saveToFile(const string& filename) const {
        ofstream file(filename);
        if (!file) {
            cerr << "Error opening file for writing: " << filename << endl;
            return;
        }

        for (const auto& customer : customers) {
            file << customer.getId() << ',' << customer.getFirstName() << ',' << customer.getLastName() << ',' << customer.getEmail() << '\n';
            for (const auto& interaction : customer.getInteractions()) {
                file << interaction.getType() << ',' << interaction.getDetails() << '\n';
            }
        }
        file.close();
    }

    // Carica i dati dei clienti da un file
    void loadFromFile(const string& filename) {
        ifstream file(filename);
        if (!file) {
            cerr << "Error opening file for reading: " << filename << endl;
            return;
        }

        customers.clear();
        string line;
        while (getline(file, line)) {
            istringstream iss(line);
            string token;
            vector<string> tokens;

            while (getline(iss, token, ',')) {
                tokens.push_back(token);
            }

            if (tokens.size() == 4) {
                int id = stoi(tokens[0]);
                string firstName = tokens[1];
                string lastName = tokens[2];
                string email = tokens[3];

                customers.emplace_back(id, firstName, lastName, email);
                nextCustomerId = max(nextCustomerId, id + 1);
            } else if (tokens.size() == 2) {
                string type = tokens[0];
                string details = tokens[1];

                if (!customers.empty()) {
                    customers.back().addInteraction(Interaction(type, details));
                }
            }
        }
        file.close();
    }
};

// Funzioni per l'interfaccia utente
void showMenu() {
    cout << "1. Aggiungi Cliente" << endl;
    cout << "2. Visualizza Clienti" << endl;
    cout << "3. Modifica Cliente" << endl;
    cout << "4. Elimina Cliente" << endl;
    cout << "5. Cerca Cliente" << endl;
    cout << "6. Gestisci Interazioni" << endl;
    cout << "7. Salva Dati" << endl;
    cout << "8. Carica Dati" << endl;
    cout << "9. Esci" << endl;
    cout << "Scegli un'opzione: ";
}

void addCustomer(CRMSystem& crm) {
    string firstName, lastName, email;
    cout << "Inserisci il nome: ";
    cin >> firstName;
    cout << "Inserisci il cognome: ";
    cin >> lastName;
    cout << "Inserisci l'email: ";
    cin >> email;
    crm.addCustomer(firstName, lastName, email);
    cout << "Cliente aggiunto con successo!" << endl;
}

void viewCustomers(const CRMSystem& crm) {
    auto customers = crm.getCustomers();
    for (const auto& customer : customers) {
        cout << "ID: " << customer.getId() << ", Nome: " << customer.getFirstName() << " " << customer.getLastName() << ", Email: " << customer.getEmail() << endl;
    }
}

void modifyCustomer(CRMSystem& crm) {
    int id;
    cout << "Inserisci l'ID del cliente da modificare: ";
    cin >> id;
    Customer* customer = crm.findCustomerById(id);
    if (customer) {
        string firstName, lastName, email;
        cout << "Inserisci il nuovo nome (lascia vuoto per mantenere invariato): ";
        cin.ignore();
        getline(cin, firstName);
        cout << "Inserisci il nuovo cognome (lascia vuoto per mantenere invariato): ";
        getline(cin, lastName);
        cout << "Inserisci la nuova email (lascia vuoto per mantenere invariato): ";
        getline(cin, email);

        if (!firstName.empty()) customer->setFirstName(firstName);
        if (!lastName.empty()) customer->setLastName(lastName);
        if (!email.empty()) customer->setEmail(email);

        cout << "Cliente modificato con successo!" << endl;
    } else {
        cout << "Cliente non trovato!" << endl;
    }
}

void deleteCustomer(CRMSystem& crm) {
    int id;
    cout << "Inserisci l'ID del cliente da eliminare: ";
    cin >> id;
    crm.removeCustomerById(id);
    cout << "Cliente eliminato con successo!" << endl;
}

void searchCustomer(const CRMSystem& crm) {
    string name;
    cout << "Inserisci il nome o il cognome del cliente da cercare: ";
    cin >> name;
    auto customers = crm.getCustomers();
    for (const auto& customer : customers) {
        if (customer.getFirstName() == name || customer.getLastName() == name) {
            cout << "ID: " << customer.getId() << ", Nome: " << customer.getFirstName() << " " << customer.getLastName() << ", Email: " << customer.getEmail() << endl;
        }
    }
}

void manageInteractions(CRMSystem& crm) {
    int id;
    cout << "Inserisci l'ID del cliente per gestire le interazioni: ";
    cin >> id;
    Customer* customer = crm.findCustomerById(id);
    if (customer) {
        cout << "1. Aggiungi Interazione" << endl;
        cout << "2. Visualizza Interazioni" << endl;
        cout << "Scegli un'opzione: ";
        int choice;
        cin >> choice;
        if (choice == 1) {
            string type, details;
            cout << "Inserisci il tipo di interazione (Appuntamento/Contratto): ";
            cin >> type;
            cout << "Inserisci i dettagli: ";
            cin.ignore();
            getline(cin, details);
            customer->addInteraction(Interaction(type, details));
            cout << "Interazione aggiunta con successo!" << endl;
        } else if (choice == 2) {
            for (const auto& interaction : customer->getInteractions()) {
                cout << "Tipo: " << interaction.getType() << ", Dettagli: " << interaction.getDetails() << endl;
            }
        }
    } else {
        cout << "Cliente non trovato!" << endl;
    }
}

int main() {
    CRMSystem crm;
    while (true) {
        showMenu();
        int choice;
        cin >> choice;

        switch (choice) {
            case 1:
                addCustomer(crm);
                break;
            case 2:
                viewCustomers(crm);
                break;
            case 3:
                modifyCustomer(crm);
                break;
            case 4:
                deleteCustomer(crm);
                break;
            case 5:
                searchCustomer(crm);
                break;
            case 6:
                manageInteractions(crm);
                break;
            case 7: {
                string filename;
                cout << "Inserisci il nome del file: ";
                cin >> filename;
                crm.saveToFile(filename);
                break;
            }
            case 8: {
                string filename;
                cout << "Inserisci il nome del file: ";
                cin >> filename;
                crm.loadFromFile(filename);
                break;
            }
            case 9:
                return 0;
            default:
                cout << "Opzione non valida, riprova." << endl;
        }
    }
    return 0;
}


